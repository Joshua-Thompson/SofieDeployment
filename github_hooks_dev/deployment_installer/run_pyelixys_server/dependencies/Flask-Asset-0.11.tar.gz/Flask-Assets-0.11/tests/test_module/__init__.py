"""This is here so that the tests have a Python package available
that can serve as the base for Flask modules used during testing.
"""